#ifndef	MEMORY_FREE_H
#define MEMORY_FREE_H

int freeMemory();

#endif